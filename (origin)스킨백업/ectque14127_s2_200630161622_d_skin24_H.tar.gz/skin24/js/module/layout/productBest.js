$(document).ready(function(){
    $(".xans-layout-productbest ol").roate({
        'duration' : '1000',
        'interval' : 3000,
        'stopButton' : '#popular-stopButton',
        'playButton' : '#popular-playButton',
        'prevButton' : '#popular-prevButton',
        'nextButton' : '#popular-nextButton',
        'movement'  : 'top',
        'opacity' : false,
        'autoStart' : true
    });
});
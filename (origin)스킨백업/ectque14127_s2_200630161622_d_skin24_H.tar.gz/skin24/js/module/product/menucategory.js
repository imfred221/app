$(function(){ 
    if($(".menuCategory > li").length==0){
         $(".menuCategory").hide();
    };
});